## 04 ALTA Y LOGIN

Hacer dos vistas:

**alta.php**
Formulario de alta donde se pedirán al menos:
- nombre y apellidos
- telefono
- email (será nuestro nombre de usuario) *
- password *
- imagen

* -> campos obligatorios

Tendremos que hacer control de errores. Dichos datos se guardarán en disco, en formato json. Podemos guardar más de un usuario. 

**login.php**
Formulario para loguearnos con alguno de los usuarios guardados en el archivo json. Se usará el email como usuario y la contraseña.
Si nos logueamos correctamente, mostraremos la información 


